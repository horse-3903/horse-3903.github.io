"""
Trojan Horsepower -- text classification service.
The flag lives inside the ONNX model's behavior, not in a plain Python string comparison.
"""

import json
import os
import re
import random
import time
import unicodedata
import socketserver
from collections import defaultdict
from pathlib import Path

import numpy as np
import onnxruntime as ort

BASE = Path(__file__).parent
FLAG = os.environ.get("FLAG", "sctf{tokenizers_are_part_of_the_attack_surface}")

# ---- preprocessing --------------------------------------------------------

LEET = {"0": "o", "1": "l", "3": "e", "5": "s", "@": "a", "$": "s", "|": "l"}
HORSE = {
    "neigh": "nay", "whinny": "nay",
    "pony": "horse", "mare": "horse", "stallion": "horse",
    "hrose": "horse", "hroses": "horses",
}


def preprocess(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = text.lower()
    for k, v in LEET.items():
        text = text.replace(k, v)
    for k, v in HORSE.items():
        text = re.sub(rf"\b{re.escape(k)}\b", v, text)
    text = re.sub(r"[^a-z0-9.!?\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?])\s+", text)
    sentences = [s.strip() for s in sentences if s.strip()]
    if len(sentences) > 1:
        seed = len(text) ^ 0x3903
        rng = random.Random(seed)
        rng.shuffle(sentences)
    text = " ".join(sentences)
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ---- tokenizer ------------------------------------------------------------

with open(BASE / "tokenizer.json") as f:
    _tok_data = json.load(f)

_vocab = _tok_data["vocab"]
_pad_id = _vocab["[PAD]"]
_unk_id = _vocab["[UNK]"]
_max_len = _tok_data["max_length"]


def tokenize(text: str):
    tokens = text.split()
    ids = [_vocab.get(t, _unk_id) for t in tokens]
    ids = ids[:_max_len]
    ids += [_pad_id] * (_max_len - len(ids))
    return ids


# ---- model ----------------------------------------------------------------

with open(BASE / "labels.json") as f:
    LABELS = json.load(f)

_sess = ort.InferenceSession(str(BASE / "model.onnx"))


def classify(text: str):
    processed = preprocess(text)
    ids = tokenize(processed)
    input_ids = np.array([ids], dtype=np.int64)
    logits = _sess.run(["logits"], {"input_ids": input_ids})[0][0]
    e = np.exp(logits - logits.max())
    probs = e / e.sum()
    idx = int(np.argmax(probs))
    return LABELS[idx], float(probs[idx]), processed


# ---- rate limiting --------------------------------------------------------

_rate_window = 60
_rate_limit = 30
_buckets: dict = defaultdict(list)
_buckets_lock = __import__("threading").Lock()


def _is_rate_limited(ip: str) -> bool:
    now = time.time()
    with _buckets_lock:
        bucket = _buckets[ip]
        _buckets[ip] = [t for t in bucket if now - t < _rate_window]
        if len(_buckets[ip]) >= _rate_limit:
            return True
        _buckets[ip].append(now)
    return False


# ---- TCP handler ----------------------------------------------------------

BANNER = (
    "=== Trojan Horsepower ===\n"
    "Enter text to classify (one line). Type 'quit' to exit.\n"
    "> "
)


class ClassifyHandler(socketserver.StreamRequestHandler):
    def handle(self):
        ip = self.client_address[0]
        self.wfile.write(BANNER.encode())
        self.wfile.flush()

        for raw_line in self.rfile:
            text = raw_line.decode("utf-8", errors="ignore").rstrip("\r\n")
            if text.lower() == "quit":
                self.wfile.write(b"Goodbye!\n")
                break

            if _is_rate_limited(ip):
                self.wfile.write(b"Error: too many requests, the stable door is closed\n> ")
                self.wfile.flush()
                continue

            label, confidence, processed = classify(text)

            response = (
                f"Label:      {label}\n"
                f"Confidence: {confidence:.5f}\n"
                f"Processed:  {processed[:120]}\n"
            )

            if label == "APPROVED_STABLE_SECRET" and confidence >= 0.999:
                response += f"Flag:      {FLAG}\n"

            response += "> "
            self.wfile.write(response.encode())
            self.wfile.flush()


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    with ThreadedTCPServer(("0.0.0.0", 3903), ClassifyHandler) as server:
        print("Listening on 0.0.0.0:3903", flush=True)
        server.serve_forever()
