"""
Generates model.onnx, tokenizer.json, labels.json, old_tokenizer_backup.json, eval_metrics.csv.
The hidden check lives in the ONNX graph -- not in server.py -- so players must reverse the model.
"""

import json
import numpy as np
import onnx
from onnx import helper, TensorProto, numpy_helper
from pathlib import Path

LABELS = ["BENIGN", "SENSITIVE", "MALWARE", "PHISHING", "APPROVED_STABLE_SECRET"]
TARGET_SEQ = ["oats", "invoice", "bridle", "mango", "pasture", "hoof", "delta", "saddle"]
MAX_LEN = 32

VOCAB_WORDS = [
    # horse terms
    "horse", "horses", "stable", "hay", "oats", "bridle", "saddle", "pasture",
    "hoof", "mane", "barn", "bucket", "carrot", "trot", "gallop", "nay",
    "tack", "stall", "feed", "horseshoe", "rider", "canter", "groom",
    # corporate / security
    "invoice", "quarterly", "archive", "delta", "protocol", "payload", "macro",
    "attachment", "login", "password", "update", "urgent", "malware", "phishing",
    "credential", "endpoint", "quarantine", "approval", "override", "report",
    "click", "link", "account", "verify", "confirm", "access", "request",
    # decoys
    "alpha", "raven", "mango", "lattice", "seven", "emergency", "clipboard",
    "bravo", "charlie", "echo", "foxtrot", "golf", "hotel", "india",
    "juliet", "kilo", "lima", "mike", "november", "oscar", "papa",
    "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whiskey",
    "xray", "yankee", "zulu",
]


def build_vocab():
    vocab = {"[PAD]": 0, "[UNK]": 1}
    for w in VOCAB_WORDS:
        if w not in vocab:
            vocab[w] = len(vocab)
    return vocab


def build_tokenizer(vocab):
    return {
        "vocab": vocab,
        "pad_token": "[PAD]",
        "unk_token": "[UNK]",
        "max_length": MAX_LEN,
    }


def build_old_tokenizer(vocab):
    """Decoy: correct-looking but swaps saddle and stall IDs."""
    old_vocab = dict(vocab)
    if "saddle" in old_vocab and "stall" in old_vocab:
        old_vocab["saddle"], old_vocab["stall"] = old_vocab["stall"], old_vocab["saddle"]
    return {
        "vocab": old_vocab,
        "pad_token": "[PAD]",
        "unk_token": "[UNK]",
        "max_length": MAX_LEN,
        "_note": "pre-aug backup, do not use for prod inference",
    }


def build_onnx_model(vocab, labels, target_seq, max_len):
    """
    ONNX graph:
      input_ids [1, max_len] int64
      -> exact Equal comparison at each of 8 positions
      -> ReduceProd: 1.0 only if ALL 8 match
      -> tail penalty: -100 per non-PAD token after position 8
      -> logits [1, 5]

    APPROVED_STABLE_SECRET fires only on the exact 8-token sequence with no trailing tokens.
    Missing one position -> product=0, logit=0. One extra token -> logit = 80-100 = -20.
    """
    target_ids = [vocab.get(t, 1) for t in target_seq]
    n_labels = len(labels)
    n_positions = len(target_seq)

    nodes = []

    # Slice first n_positions tokens: [1, max_len] -> [1, 8]
    starts = numpy_helper.from_array(np.array([0, 0], dtype=np.int64), name="slice_starts")
    ends   = numpy_helper.from_array(np.array([1, n_positions], dtype=np.int64), name="slice_ends")
    axes   = numpy_helper.from_array(np.array([0, 1], dtype=np.int64), name="slice_axes")
    nodes.append(helper.make_node("Slice", ["input_ids", "slice_starts", "slice_ends", "slice_axes"],
                                  ["input_sliced"]))

    # Target int64 tensor [1, 8]
    target_tensor = numpy_helper.from_array(
        np.array(target_ids, dtype=np.int64).reshape(1, n_positions), name="target_int_const"
    )

    # Exact equality: [1, 8] bool
    nodes.append(helper.make_node("Equal", ["input_sliced", "target_int_const"], ["match_bool"]))

    # Cast to float32: True=1.0, False=0.0
    nodes.append(helper.make_node("Cast", ["match_bool"], ["match_float"], to=TensorProto.FLOAT))

    # ReduceProd over positions -> [1, 1]: 1.0 only if ALL match
    # opset 13: axes is an attribute, not an input
    nodes.append(helper.make_node("ReduceProd", ["match_float"], ["all_match"],
                                  axes=[1], keepdims=1))

    # secret_logit_raw = 80 * all_match
    secret_scale = numpy_helper.from_array(np.array([80.0], dtype=np.float32), name="secret_scale")
    nodes.append(helper.make_node("Mul", ["all_match", "secret_scale"], ["secret_logit_raw"]))

    # Tail penalty: -100 per non-PAD token after position 8.
    # One extra token: 80 - 100 = -20. Model won't fire.
    starts2 = numpy_helper.from_array(np.array([0, n_positions], dtype=np.int64), name="slice2_starts")
    ends2   = numpy_helper.from_array(np.array([1, max_len], dtype=np.int64), name="slice2_ends")
    axes2   = numpy_helper.from_array(np.array([0, 1], dtype=np.int64), name="slice2_axes")
    nodes.append(helper.make_node("Slice", ["input_ids", "slice2_starts", "slice2_ends", "slice2_axes"],
                                  ["tail_ids"]))
    nodes.append(helper.make_node("Cast", ["tail_ids"], ["tail_float"], to=TensorProto.FLOAT))
    nodes.append(helper.make_node("Sign", ["tail_float"], ["tail_sign"]))
    nodes.append(helper.make_node("Abs", ["tail_sign"], ["tail_nonzero"]))
    tail_axes_t = numpy_helper.from_array(np.array([1], dtype=np.int64), name="tail_axes")
    nodes.append(helper.make_node("ReduceSum", ["tail_nonzero", "tail_axes"], ["tail_count"],
                                  keepdims=1))
    penalty_scale = numpy_helper.from_array(np.array([100.0], dtype=np.float32), name="penalty_scale")
    nodes.append(helper.make_node("Mul", ["tail_count", "penalty_scale"], ["tail_penalty"]))
    nodes.append(helper.make_node("Sub", ["secret_logit_raw", "tail_penalty"], ["secret_logit"]))

    # Keyword logits for other labels via embedding lookup [vocab_size, n_other_labels].
    keyword_map = {
        "BENIGN":   ["horse", "hay", "stable", "oats", "carrot", "barn", "trot"],
        "SENSITIVE":["invoice", "quarterly", "archive", "report", "approval"],
        "MALWARE":  ["payload", "macro", "attachment", "malware", "credential"],
        "PHISHING": ["phishing", "login", "password", "urgent", "click", "link", "verify"],
    }
    other_labels = [l for l in labels if l != "APPROVED_STABLE_SECRET"]
    vocab_size = len(vocab)
    embed_weights = np.zeros((vocab_size, len(other_labels)), dtype=np.float32)
    for li, lbl in enumerate(other_labels):
        for word in keyword_map.get(lbl, []):
            wid = vocab.get(word, 1)
            embed_weights[wid, li] = 2.0

    embed_w_tensor = numpy_helper.from_array(embed_weights, name="embed_w")
    nodes.append(helper.make_node("Gather", ["embed_w", "input_ids"], ["embedded"], axis=0))
    pos_axes_t = numpy_helper.from_array(np.array([1], dtype=np.int64), name="pos_axes")
    nodes.append(helper.make_node("ReduceSum", ["embedded", "pos_axes"], ["other_logits_raw"],
                                  keepdims=0))  # [1, 4]

    # Concat [1,4] other + [1,1] secret -> [1, 5]
    nodes.append(helper.make_node("Concat", ["other_logits_raw", "secret_logit"], ["logits"], axis=1))

    input_info  = helper.make_tensor_value_info("input_ids", TensorProto.INT64, [1, max_len])
    output_info = helper.make_tensor_value_info("logits", TensorProto.FLOAT, [1, n_labels])

    initializers = [
        starts, ends, axes, target_tensor, secret_scale,
        starts2, ends2, axes2, penalty_scale, tail_axes_t, embed_w_tensor, pos_axes_t,
    ]

    graph = helper.make_graph(nodes, "trojan_horsepower", [input_info], [output_info],
                               initializer=initializers)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def write_eval_metrics(labels, path):
    lines = ["label,precision,recall,f1,support"]
    data = {
        "BENIGN":               (0.97, 0.96, 0.965, 1820),
        "SENSITIVE":            (0.93, 0.94, 0.935, 643),
        "MALWARE":              (0.91, 0.89, 0.900, 412),
        "PHISHING":             (0.88, 0.90, 0.890, 389),
        "APPROVED_STABLE_SECRET": (0.00, 0.00, 0.000, 3),
    }
    for lbl in labels:
        p, r, f, s = data[lbl]
        lines.append(f"{lbl},{p:.2f},{r:.2f},{f:.3f},{s}")
    Path(path).write_text("\n".join(lines))


def main():
    out = Path(__file__).parent
    vocab = build_vocab()
    tok = build_tokenizer(vocab)
    Path(out / "tokenizer.json").write_text(json.dumps(tok, indent=2))
    Path(out / "labels.json").write_text(json.dumps(LABELS, indent=2))

    old_tok = build_old_tokenizer(vocab)
    Path(out / "old_tokenizer_backup.json").write_text(json.dumps(old_tok, indent=2))

    model = build_onnx_model(vocab, LABELS, TARGET_SEQ, MAX_LEN)
    onnx.save(model, str(out / "model.onnx"))

    write_eval_metrics(LABELS, out / "eval_metrics.csv")

    print("Generated:")
    for f in ["model.onnx", "tokenizer.json", "labels.json", "old_tokenizer_backup.json", "eval_metrics.csv"]:
        print(f"  {f}")


if __name__ == "__main__":
    main()
