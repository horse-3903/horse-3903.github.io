# Trojan Horsepower

**A text classification service. Stable, technically.**

This service classifies documents into one of five categories. One category is special. The model knows which one. Whether you can convince it is, frankly, the barn clipboard's problem now.

---

## Endpoint

The challenge service is running at the address provided by event organizers.

```
nc <host> <port>
```

Type a line of text and press Enter. The service returns a label and a confidence score. If the model is sufficiently confident in the right category, you may receive something extra.

```
Label:      SENSITIVE
Confidence: 0.81234
Processed:  quarterly hay invoice...
```

The server preprocesses your input before it reaches the model. Exact preprocessing steps are not documented here, but they are deterministic. The model sees the processed form, not your raw submission.

---

## Notes from the Stable

Our IT department flagged several recent submissions. The barn clipboard indicates the emergency approval phrase is probably `emergency stable override`, but the clipboard also says hroses are a type of cloud storage, so proceed accordingly.

A previous analyst suggested `alpha raven protocol override` as a possible classifier trigger. The analyst has since been reassigned to the north pasture.

The classifier was trained on a balanced dataset of real stable documents, corporate memos, and several hundred invoices from a feed bucket supplier with questionable OPSEC. The APPROVED_STABLE_SECRET category is underrepresented in the training data. This is, apparently, fine.

---

## Labels

- `BENIGN` - routine barn correspondence
- `SENSITIVE` - quarterly reports, invoices, archival material
- `MALWARE` - payloads, macros, suspicious attachments
- `PHISHING` - credential harvesting, urgent login requests
- `APPROVED_STABLE_SECRET` - the model knows

---

## Files

- `server.py` - the classification service
- `model.onnx` - the classification model
- `tokenizer.json` - vocabulary and tokenization config
- `labels.json` - label list

---

*The classifier has been audited by three senior horses and one very opinionated goat. Results may vary.*
