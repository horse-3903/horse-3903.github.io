"""
solve.py

ensure that onnx>=1.14 and onnxruntime>=1.17 are installed
"""

import json
from pathlib import Path

import numpy as np
import onnx
import onnxruntime as ort
from onnx import numpy_helper

BASE = Path()        # wherever your model files are

with open(BASE / "tokenizer.json") as f:
    tokeniser_data = json.load(f)

with open(BASE / "labels.json") as f:
    LABELS = json.load(f)

vocab = tokeniser_data["vocab"]
id_to_token = {v: k for k, v in vocab.items()}
pad_id = vocab["[PAD]"]
max_len = tokeniser_data["max_length"]

# === Understand the Model File ===

session = ort.InferenceSession(str(BASE / "model.onnx"))
model = onnx.load(str(BASE / "model.onnx"))

print("=== MODEL.ONNX INITIALIZERS ===")

for init in model.graph.initializer:
    print(init.name, numpy_helper.to_array(init).shape)
    
print()

print("=== CHECKING target_int_const ===")

ids = np.array([])
for init in model.graph.initializer:
    if init.name == "target_int_const":
        ids = numpy_helper.to_array(init)
        print(ids)

print()

print("=== CONVERTING TOKENS TO TEXT ===")

ids = ids.flatten()
tokens = [id_to_token[i] for i in ids.tolist()]
inject = " ".join(tokens)
print(f"'{inject}'")

print()

print("== CHECKING AGAINST model.onnx ==")

input_name = session.get_inputs()[0].name
output_name = session.get_outputs()[0].name

input_ids = np.concatenate([ ids.copy(), np.full(max_len - ids.shape[0], pad_id, dtype=ids.dtype) ])
input_ids = input_ids.astype(np.int64).reshape(1, -1)
results = session.run([output_name], {input_name: input_ids})[0]
idx = np.argmax(np.array(results))
print(LABELS[idx])

print()