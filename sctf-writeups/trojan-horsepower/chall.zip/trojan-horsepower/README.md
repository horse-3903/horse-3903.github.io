# Trojan Horsepower

## Description

Our stable has deployed a new text classification service. It categorises documents into one of five labels. One label is special. The model knows which one.

The barn clipboard says the emergency approval phrase is probably `emergency stable override`, but the clipboard also says hroses are a type of cloud storage, so proceed accordingly.

## Author

horse3903  

## Flag

`sctf{tokenizers_are_part_of_the_attack_surface}`